public class Empleados {
    private String cedula;
    private String nombre;
    private String apellido;
    private String genero;
    private double salario;

    // Constructor
    public Empleados(String cedula, String nombre, String apellido, String genero, double salario) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.genero = genero;
        this.salario = salario;
    }


    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }


    public double calcularPrestaciones(int antiguedad) {
        return (antiguedad * salario) / 12;
    }


    public String mostrarInformacion() {
        return "Cédula: " + cedula + "\nNombre: " + nombre + "\nApellido: " + apellido +
                "\nGénero: " + genero + "\nSalario: " + salario;
    }
}

