import javax.swing.*;

public class MainEmpleado {
    public static void main(String[] args) {

        String cedula = JOptionPane.showInputDialog("Ingrese la cédula del empleado:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del empleado:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido del empleado:");
        String genero = JOptionPane.showInputDialog("Ingrese el género del empleado:");
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el salario del empleado:"));


        Empleados empleado = new Empleados(cedula, nombre, apellido, genero, salario);


        int opcion;
        do {

            String menu = "Seleccione una opción:\n" +
                    "1. Modificar Salario\n" +
                    "2. Calcular Prestaciones\n" +
                    "3. Mostrar Información\n" +
                    "4. Salir";
            opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcion) {
                case 1: // Modificar salario
                    double nuevoSalario = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el nuevo salario:"));
                    empleado.setSalario(nuevoSalario);
                    JOptionPane.showMessageDialog(null, "Salario modificado con éxito.");
                    break;
                case 2: // Calcular prestaciones
                    int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la antigüedad en años:"));
                    double prestaciones = empleado.calcularPrestaciones(antiguedad);
                    JOptionPane.showMessageDialog(null, "Las prestaciones del empleado son: " + prestaciones);
                    break;
                case 3: // Mostrar información
                    JOptionPane.showMessageDialog(null, empleado.mostrarInformacion());
                    break;
                case 4: // Salir
                    JOptionPane.showMessageDialog(null, "Saliendo de la aplicación.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 4);
    }
}
