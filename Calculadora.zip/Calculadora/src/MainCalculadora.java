import javax.swing.*;

public class MainCalculadora {
    public static void main(String[] args) {
        Calculadora calculadora = new Calculadora();

        // Solicitar al usuario ingresar dos números
        double num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el primer número:"));
        double num2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el segundo número:"));

        // Mostrar menú de selección de operación
        String menu = "Seleccione la operación:\n" +
                "1. Suma\n" +
                "2. Resta\n" +
                "3. Multiplicación\n" +
                "4. División";
        int opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

        double resultado;

        // Realizar la operación seleccionada
        switch (opcion) {
            case 1: // Suma
                resultado = calculadora.sumar(num1, num2);
                JOptionPane.showMessageDialog(null, "El resultado de la suma es: " + resultado);
                break;

            case 2: // Resta
                resultado = calculadora.restar(num1, num2);
                JOptionPane.showMessageDialog(null, "El resultado de la resta es: " + resultado);
                break;

            case 3: // Multiplicación
                resultado = calculadora.multiplicar(num1, num2);
                JOptionPane.showMessageDialog(null, "El resultado de la multiplicación es: " + resultado);
                break;

            case 4: // División
                if (num2 == 0) {
                    JOptionPane.showMessageDialog(null, "Error: No se puede dividir entre cero.");
                } else {
                    resultado = calculadora.dividir(num1, num2);
                    JOptionPane.showMessageDialog(null, "El resultado de la división es: " + resultado);
                }
                break;

            default:
                JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, seleccione una operación válida.");
                break;
        }
    }
}

