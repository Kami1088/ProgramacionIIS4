public class Producto {
    private String nombre;
    private double precio;
    private int tieneIVA;


    public Producto(String nombre, double precio, int tieneIVA) {
        this.nombre = nombre;
        this.precio = precio;
        this.tieneIVA = tieneIVA;
    }

    public double calcularPrecioFinal() {
        double iva = 0.0;

        if (tieneIVA == 1) {
            if (precio <= 500) {
                iva = 0.12; // 12%
            } else if (precio <= 1500) {
                iva = 0.14; // 14%
            } else {
                iva = 0.15; // 15%
            }
            return precio + (precio * iva);
        }
        return precio;
    }

    public String mostrarInformacion() {
        return "Nombre: " + nombre + "\n" +
                "Precio: " + precio + "\n" +
                "¿Tiene IVA?: " + (tieneIVA == 1 ? "Sí" : "No") + "\n" +
                "Precio Final: " + calcularPrecioFinal();
    }
}
