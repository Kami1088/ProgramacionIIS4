import javax.swing.*;

public class MainProducto {
    public static void main(String[] args) {

        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
        double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del producto:"));


        String menuIVA = "¿El producto tiene IVA?\n1. Sí\n2. No";
        int tieneIVA = Integer.parseInt(JOptionPane.showInputDialog(menuIVA)); // 1 para sí, 2 para no


        Producto producto = new Producto(nombre, precio, tieneIVA);


        JOptionPane.showMessageDialog(null, producto.mostrarInformacion());
    }
}

