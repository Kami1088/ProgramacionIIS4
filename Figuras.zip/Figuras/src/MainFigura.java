import javax.swing.*;

public class MainFigura {
    public static void main(String[] args) {

        String menu = "1. Cuadrado\n" +
                "2. Rectángulo\n" +
                "3. Triángulo\n" +
                "Seleccione una figura:";

        int opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

        switch (opcion) {
            case 1: // Cuadrado
                double lado = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el lado del cuadrado:"));
                Cuadrado cuadrado = new Cuadrado(lado);
                JOptionPane.showMessageDialog(null, "Área del cuadrado: " + cuadrado.calcularArea() +
                        "\nPerímetro del cuadrado: " + cuadrado.calcularPerimetro());
                break;

            case 2: // Rectángulo
                double baseRect = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base del rectángulo:"));
                double alturaRect = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura del rectángulo:"));
                Rectangulo rectangulo = new Rectangulo(baseRect, alturaRect);
                JOptionPane.showMessageDialog(null, "Área del rectángulo: " + rectangulo.calcularArea() +
                        "\nPerímetro del rectángulo: " + rectangulo.calcularPerimetro());
                break;

            case 3: // Triángulo
                double baseTri = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base del triángulo:"));
                double alturaTri = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura del triángulo:"));
                double lado1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el lado 1 del triángulo:"));
                double lado2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el lado 2 del triángulo:"));
                double lado3 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el lado 3 del triángulo:"));
                Triangulo triangulo = new Triangulo(baseTri, alturaTri, lado1, lado2, lado3);
                JOptionPane.showMessageDialog(null, "Área del triángulo: " + triangulo.calcularArea() +
                        "\nPerímetro del triángulo: " + triangulo.calcularPerimetro());
                break;

            default:
                JOptionPane.showMessageDialog(null, "Opción Incorrecta");
                break;
        }
    }
}
